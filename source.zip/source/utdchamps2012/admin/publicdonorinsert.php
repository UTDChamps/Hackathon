

<?php 
	require_once '../include/common.php';

	if (strtoupper($_SERVER['REQUEST_METHOD']) == 'POST')
	{
// 		$insertdata = array(
// 				"username" => $_POST["username"],
// 				"email" => $_POST["email"],
// 				"GeoLatitiute" => $_POST["Lat"],
// 				"GeoLongitute" => $_POST["Lon"]
// 		);
	
		
// 		$tableName = 'publicdonormap';
		 
// 		$db = DBUtils::getDb();
// 		$db->connect();
		//$ItemArray = $db->query_insert($tableName, $insertdata);
		echo <<<HTML
		<h1> Successfully inserted</h1>
HTML;
		//$db->close();
		
		
	}

	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<?php require 'include/head.php'; ?>
    <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAuvAUEwdvrM4v49pnVIaWPNrUM_R9rpIw&sensor=true">
    </script>
		
  
  <script type="text/javascript">
  		var map;
  		var markersArray = [];
  
      function initialize() {
        var mapOptions = {
          center: new google.maps.LatLng(32.738628, -96.796246),
          zoom: 12,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById("map_canvas"),
            mapOptions);

        showAllMarkers();

        google.maps.event.addListener(map, 'click', function(event) {
        	clearOverlays();
        	document.getElementById('hdLongitute').value = event.latLng.lng();
        	document.getElementById('hdLatitude').value = event.latLng.lat();
      	    addMarker(event.latLng);
      	  });
      }

      function showAllMarkers()
      {
    	  
      }

      function showMarker(lat, lng, title)
      {
    	  var myLatlng = new google.maps.LatLng(lat, lng);
    	  addMarker(myLatlng, title)
      }

      function addMarker(myLatlng, title)
      {
    	  var marker = new google.maps.Marker({
    	      position: myLatlng,
    	      map: map,
    	      title:title
    	  });

    	  markersArray.push(marker);
    	  
      }

      function clearOverlays() {
        if (markersArray) {
          for (i in markersArray) {
            markersArray[i].setMap(null);
          }
        }
      }
       


  	      
    </script>
  
	</head>
	<body onload="initialize()">
	
		<?php require 'include/header.php'; ?>
        
		<div class="container_12">
        
<!-- Form elements -->    
            <div class="grid_12">
            
                <div class="module">
                     <h2><span>Form</span></h2>
                        
                     <div class="module-body">
                        <form action="publicdonorinsert.php" method="post">
                            
                            <p>
                                <label>Name (optional)</label>
                                <input type="text" class="input-short" name="username" />
<!--                                 <span class="notification-input ni-correct"></span> -->
                            </p>
                            
                            <p>
                                <label>Email (optional)</label>
                                <input type="text" class="input-medium" name="email" />
<!--                                 <span class="notification-input ni-error"></span> -->
                            </p>
                            
                            <p>
                            	<div id="map_canvas" style="width:700px; height:500px"></div>
                            </p>
                            
                            <p>
                            	
                            </p>
                            
                            
                            <input type="hidden" id="hdLatitude" name="lat" ></input>
                            <input type="hidden" id="hdLongitute" name="lon" ></input>
                            
                            <fieldset>
                                <input class="submit-green" type="submit" value="Submit" /> 
                            </fieldset>
                            
                        </form>
                     </div> <!-- End .module-body -->

                </div>  <!-- End .module -->
        		<div style="clear:both;"></div>
            </div> <!-- End .grid_12 -->
            
            
            <div style="clear:both;"></div>
        </div> <!-- End .container_12 -->
		
         <?php include 'include/footer.php'; ?>
         

	</body>
</html>

