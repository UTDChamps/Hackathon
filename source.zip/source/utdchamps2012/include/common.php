<?php require_once 'database.php';?>

<?php
	class SettingsClass
	{
		// database connection config
		public $dbHost = 'localhost';
		public $dbUser = 'root';
		public $dbPass = '';
		public $dbName = 'foodbank';
		
		
		function __construct() {
			// setting up the web root and server root for
			$thisFile = str_replace('\\', '/', __FILE__);
			$docRoot = $_SERVER['DOCUMENT_ROOT'];
				
			// obtaining the web root address. This will be used to address other files like images
			$webRoot = str_replace(array($docRoot, 'include/common.php'), '', $thisFile);
			$srvRoot = str_replace('include/common.php', '', $thisFile);
				
			define('WEB_ROOT', $webRoot);
			define('SRV_ROOT', $srvRoot);
				
		}
	}
	
	$settings = new SettingsClass();

	class DBUtils
	{
		static function getDb()
		{
			return new Database($GLOBALS['settings']->dbHost, $GLOBALS['settings']->dbUser, $GLOBALS['settings']->dbPass, $GLOBALS['settings']->dbName);
		}

		static function getSQLSafeValue($string)
		{
			if(get_magic_quotes_runtime()) $string = stripslashes($string);
			return @mysql_real_escape_string($string);
		}
	
	}
	
?>
