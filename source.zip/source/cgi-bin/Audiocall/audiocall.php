<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Enter your email ID</title>
</head>

<body background="how-to-create-a-grunge-web-design-using-photoshop-2009061904112149-16-04_grunge_design_2_jpg.jpg">

<p align="left">&nbsp;<font color="#0000FF"><font size="5"> </font><b>
<font size="5">&nbsp;</font></b></font><img border="0" src="north-texas-food-bank.jpg" width="202" height="160"></p>
<p align="left"><font color="#0000FF"><b>
<span style="background-color: #00FFFF"><font size="5">&nbsp;START DONATING</font></span></b></font></p>
<hr color="#0000FF" size="20" style="border: 10px inset #0000FF">

<p><font face="Aharoni">Enter your email ID:</font></p>
<p>
  <input type="text" size="40" maxlength="256" name="Donor_PhoneNum" style="border:3px inset #FFFFCC; background-color: #FFFFCC; padding-left:3; padding-right:0; padding-top:3; padding-bottom:1"></p>
<p><font face="Aharoni">Enter Your Phone Number :</font></p>
<p>
  <input type="text" size="40" maxlength="256" name="Password" style="border:3px inset #FFFFCC; background-color: #FFFFCC; padding-left:3; padding-right:0; padding-top:3; padding-bottom:1"></p>
<p>
  <input type="submit" value="Audio Call" style="border-style:double; border-width:3; color: #000000; font-weight: bold; background-color: #C0C0C0; padding-left:4; padding-right:4; padding-top:1; padding-bottom:1; background-image:url('color_gradient_jpg_image.jpg')" name="AudioCall_Button"></p>
<p>
  <input type="submit" value="Video Call" style="border-style:double; border-width:3; color: #000000; font-weight: bold; background-color: #C0C0C0; padding-left:4; padding-right:4; padding-top:1; padding-bottom:1; background-image:url('color_gradient_jpg_image.jpg')" name="VideoCall_Button"></p>
<p>&nbsp;</p>

</body>

</html>
