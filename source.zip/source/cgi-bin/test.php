<?php
$user = $_POST["Username"];
$pass = $_POST["Password"];
$con = mysql_connect("127.0.0.1","root","UTDChamps");
if (!$con){
  die('Could not connect: ' . mysql_error());
}
mysql_select_db("foodbank", $con);
$authenticate = false;
$result = mysql_query("SELECT * FROM user");
while($row = mysql_fetch_array($result)){
	if($row['UserName'] == $user && $row['Password'] == $pass){
		$authenticate = true;
	}  
}

$fooditems = mysql_query("SELECT * FROM fooditem");


mysql_close($con);

if(!$authenticate){
echo <<<HTMLTEXT

<!doctype html>
<html>
	<head>
	
		<script type="text/javascript" src="/WCGapi.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="http://maps.google.com/maps?file=api&v=3&key=AIzaSyCA8BMKM6mXfcZvicovW72iFX3Nxluqyjg&sensor=false" type="text/javascript"></script>

		<script type="text/javascript">
var geocoder, location1, location2;
var distances= new Array();
var distanceskm= new Array();
var add1= new Array();
var add2= new Array();

			var agencies = {
    "agencies": [
        {
            "name": "Agency in richardson",
            "address": "2600 Waterview parkway richardson TX 75080"
        },
        {
            "name": "Agency in dallas",
            "address": "7740, Mccallum blvd, TX 75252"
        }
    ]
};
			var donoradd = "500 North central parkway plano TX 75074";

			
    function initialize() {
        geocoder = new GClientGeocoder();
    }

    function showLocation() {
        geocoder.getLocations(donoradd, function (response) {
            if (!response || response.Status.code != 200)
            {
                alert("Sorry, we were unable to geocode the first address");
            }
            else
            {
                location1 = {lat: response.Placemark[0].Point.coordinates[1], lon: response.Placemark[0].Point.coordinates[0], address: response.Placemark[0].address};
                geocoder.getLocations(agencies.agencies[0].address, function (response) {
                    if (!response || response.Status.code != 200)
                    {
                        alert("Sorry, we were unable to geocode the second address");
                    }
                    else
                    {
                        //alert(location1.lon);
			//alert(location1.lat);
			location2 = {lat: response.Placemark[0].Point.coordinates[1], lon: response.Placemark[0].Point.coordinates[0], address: response.Placemark[0].address};
                        calculateDistance();
                    }
                });
            }
        });
    }
    

    function showLocation1() {
        geocoder.getLocations(donoradd, function (response) {
            if (!response || response.Status.code != 200)
            {
                alert("Sorry, we were unable to geocode the first address");
            }
            else
            {
                location1 = {lat: response.Placemark[0].Point.coordinates[1], lon: response.Placemark[0].Point.coordinates[0], address: response.Placemark[0].address};
                geocoder.getLocations(agencies.agencies[1].address, function (response) {
                    if (!response || response.Status.code != 200)
                    {
                        alert("Sorry, we were unable to geocode the second address");
                    }
                    else
                    {
                        //alert(location1.lon);
			//alert(location1.lat);
			location2 = {lat: response.Placemark[0].Point.coordinates[1], lon: response.Placemark[0].Point.coordinates[0], address: response.Placemark[0].address};
                        calculateDistance1();
                    }
                });
            }
        });
    }




    function calculateDistance()
    {
        try
        {
            var glatlng1 = new GLatLng(location1.lat, location1.lon);
            var glatlng2 = new GLatLng(location2.lat, location2.lon);
            var miledistance = glatlng1.distanceFrom(glatlng2, 3959).toFixed(1);
            var kmdistance = (miledistance * 1.609344).toFixed(1);

distances.push(miledistance);
distanceskm.push(kmdistance);
add1.push(location1.address);
add2.push(location2.address);


        }
        catch (error)
        {
            alert(error);
        }
    }


    function calculateDistance1()
    {
        try
        {
            var glatlng1 = new GLatLng(location1.lat, location1.lon);
            var glatlng2 = new GLatLng(location2.lat, location2.lon);
            var miledistance = glatlng1.distanceFrom(glatlng2, 3959).toFixed(1);
            var kmdistance = (miledistance * 1.609344).toFixed(1);

distances.push(miledistance);
distanceskm.push(kmdistance);
add1.push(location1.address);
add2.push(location2.address);
var finaldist=999;
var finaldistkm;
var finalloc1;
var finalloc2;
var i;
for( i=0;i<distances.length;i++){
if(finaldist > distances[i]){
	finaldist = distances[i];
 finaldistkm = distanceskm[i];
 finalloc1= add1[i];
 finalloc2 = add2;

}
}
            document.getElementById('results1').innerHTML = '<strong>Donors address: </strong>' + finalloc1 + '<br /><strong>Agency address: </strong>' + finalloc2 + '<br /><strong>Distance: </strong>' + finaldist + ' miles (or ' + finaldistkm + ' kilometers)';



        }
        catch (error)
        {
            alert(error);
        }
    }


			window.onload = function() {
				var url = document.getElementById("url");
				var turn = document.getElementById("turn");
				var login = document.getElementById("login");
				var password = document.getElementById("password");
				var register = document.getElementById("register");
				var login2 = document.getElementById("login2");
				var password2 = document.getElementById("password2");
				var register2 = document.getElementById("register2");
				var login2 = document.getElementById("login2");
				var password3 = document.getElementById("password3");
				var register3 = document.getElementById("register3");

				var unregister = document.getElementById("unregister");
				
				var recipient = document.getElementById("recipient");
				var createCall = document.getElementById("createCall");
				var endCall = document.getElementById("endCall");
				var acceptCall = document.getElementById("acceptCall");
		
				var localvideo = document.getElementById("selfView");
				var remotevideo = document.getElementById("remoteView");
				var localvideo2 = document.getElementById("selfView2");
				var remotevideo2 = document.getElementById("remoteView2");
				var videoBox = document.getElementById("videoBox");
				var localStream = null;
				var remoteStream = null;
				
				<!-- Events Confirmation Box -->
				var boxRegister = document.getElementById("boxRegister");
				var boxRegister2 = document.getElementById("boxRegister2");
				var boxCallSent = document.getElementById("boxCallSent");
				var boxCallReceived = document.getElementById("boxCallReceived");
				var boxUnregister = document.getElementById("boxUnregister");
				
				
				var service = null;
				var call = null;
				var usernamechat;
				var usernamechat2;
				
				function registerfunc() {
					// Media service
					service = new MediaServices(url.value, login.value, password.value, "audio,video");
					service.turnConfig = turn.value;
					service.onclose = serviceOnClose;
					service.onerror = serviceOnError;
					service.oninvite = serviceOnInvite;
					service.onready = serviceOnReady;
					service.onstatechange = serviceOnStateChange;
					usernamechat = login.value;
					usernamechat2 = login.value;
				
					
				};				

				// User login
				register.onclick = registerfunc;
				
				
				unregister.onclick = function() {
					service.unregister();
					boxRegister.style.visibility = "hidden";
				};
				

				endCall.onclick = function() {
					localStream.stop();
					remoteStream.stop();
					call.end();					
								
				};

				/************************************************************************
				 * Call																	*
				 ***********************************************************************/
				
				
				
								
				/************************************************************************
				 * Service handlers below												*
				 ***********************************************************************/
				
				function serviceOnClose(event) {
					console.log("[MediaServices] Closed");
					boxCallReceived.style.visibility = 'hidden';
					boxCallSent.style.visibility = 'hidden';
					videoBox.style.display = "none";
					boxUnregister.style.visibility = 'visible';
					boxUnregister.style.backgroundColor = '#99FF33';
					boxRegister.style.visibility = 'hidden';
					boxRegister.style.backgroundColor = '#E9FA7A';
					boxCallReceived.style.visibility = 'hidden';
					boxCallReceived.style.backgroundColor = '#FC8E7F';
					boxCallSent.style.visibility = 'hidden';
					boxCallSent.style.backgroundColor = '#FC8E7F';
				};
				
			
				
				function serviceOnError(event) {
					console.log("[MediaServices] Error: " + event.type + " " + event.reason + " " + event.target);
				};
				
				function serviceOnInvite(event) {
					if (event.call) {
						console.log("[MediaServices] Received call invite");
						boxCallReceived.style.visibility = 'visible';
						boxCallReceived.style.backgroundColor = '#99FF33';
						
						acceptCall.onclick = function() {
							videoBox.style.display = "block";
							call = event.call;
							call.answer();
							if(call.recipient.match('/7366/')){
							    donoradd = "500 North central parkway plano TX 75074";
							}else{
								donoradd = "4500 south cockrell hill road dallas texas 75236";
							}
		
							initialize();
							showLocation();
							showLocation1();

							
							call.onaddstream = callOnAddStream;
							call.onbegin = callOnBegin;
							call.onend = callOnEnd;
							call.onerror = callOnError;
							call.onremovestream = callOnRemoveStream;
							call.onstatechange = callOnStateChange;
						};
						
						endCall.onclick = function() {
							event.call.end();
							boxCallReceived.style.visibility = 'hidden';
							videoBox.style.display = "none";
						};
						
						
						
					}
				};
				
				function serviceOnReady(event) {
					console.log("[MediaServices] Ready");
					boxRegister.style.visibility = 'visible';
					boxRegister.style.backgroundColor = '#99FF33';
					boxUnregister.style.visibility = 'hidden';
				};
				
				
				
				function serviceOnStateChange(event) {
					console.log("[MediaServices] State changed: " + event.type + " " + event.state);
				};
				
				/************************************************************************
				 * Call handlers below													*
				 ***********************************************************************/
				
				function callOnAddStream(event) {
					if (event.call.localStreams) {
						console.log("[Call] Local stream added");
						var url = webkitURL.createObjectURL(event.call.localStreams[0]);
						localvideo.style.opacity = 1;
						localvideo.src = url;
						localStream = event.call.localStreams[0];
					}
					if (event.call.remoteStreams) {
						console.log("[Call] Remote stream added");
						var url = webkitURL.createObjectURL(event.call.remoteStreams[0]);
						remotevideo.style.opacity = 1;
						remotevideo.src = url;
						remoteStream = event.call.remoteStreams[0];
					}
				};
				
				function callOnBegin(event) {
					console.log("[Call] Call has started");
					videoBox.style.display = "block";
					videoBox.style.visibility = "visible";
				};
				
				function callOnEnd(event) {
					console.log("[Call] Call has ended");
					boxCallReceived.style.visibility = 'hidden';
					videoBox.style.display = "none";
				};
				
				function callOnError(event) {

				console.log("[Call] Error: " + event.type + " " + event.reason + " " + event.target);
					
				};
				
				function callOnRemoveStream(event) {
					console.log("[Call] Stream removed");
					localStream.stop();
					remoteStream.stop(); 
					// Do stuff with event.call.remoteStreams
				};
				
				function callOnStateChange(event) {
					console.log("[Call] State changed: " + call.state);
				};
		
			registerfunc();	
			};
			
		</script>
		<script>
		$(window).unload(function(){
			$(unregister).click();			
		});
		window.onclose = function(){
			$(unregister).click();			
		}
		</script>


	</head>
	
	<body style="background-color:#D0FAEE">
		<H1>Logged in ... waiting for incoming calls...</H1>
		
		<div id="MainContainer">
			<!-- Media services -->
				<input id="url" type="hidden" value="http://10.97.33.50:38080/HaikuServlet/rest/v2/" size="40" />
				<input id="turn" type="hidden" value="STUN 10.97.33.50:4242" /><br />
				<input id="login" type="hidden" value="sip:16509992350@vims1.com" />
				<input id="password" type="hidden" value="EECpa\$\$w0rd" />
				<button id="register" style="display:none">Login</button>
				<label id="boxRegister" style="visibility: hidden; background-color:#E9FA7A">Registered Success!</label>
				<br />
				<button id="unregister" style="display:none">Logout</button><br /><br />
				<div id="boxUnregister" style="visibility: hidden; background-color:#E9FA7A">Unregistration Successful! All fields refreshed...</div>

			
			
			
			<!-- Call -->
				<div id="boxCallReceived" style="visibility: hidden; background-color:#FC8E7F">Call Received!
				<button id="acceptCall">Accept call</button>
				<button id="endCall">End/Reject call</button>
				<div id ="results1"> </div>
				</div>
				<div id="videoBox" style="background-color:none; display:none;">
				<H3>The video box is below</H3>
				<video id="selfView"
					width="320" height="240" style="opacity: 0;
					-webkit-transition-property: opacity;
					-webkit-transition-duration: 2s;" muted autoplay controls></video>
				<video id="remoteView"
					width="320" height="240" style="opacity: 0;
					-webkit-transition-property: opacity;
					-webkit-transition-duration: 2s;" muted autoplay controls></video>
<form name="donor" action="http://hackathon3.explab.com/cgi-bin/add.php" method="post">

					<ul>
HTMLTEXT;


while($row = mysql_fetch_array($fooditems)){
	echo "<li>".$row['FoodItemTitle']."<br/>"."<input type=\"text\" name=\"".$row['FoodItemTitle']."\"/></li>";
}

			
echo <<<HTMLTEXT
</ul>
				</div><br />	
<div>

Name : <input type="text name="address" id="name" />
Address : <input type="text name="address" id="address" />
Phone : <input type="text name="address" id="phone" />
</form>
</div>
		</div>	
	</body>
</html>




HTMLTEXT;
}else{
echo <<<HTMLTEXT

<!doctype html>
<html>
	<head> <title>Unauthorized</title></head>
<html>
<body>
<h1> Unauthorized</h1>
</body>
</html>
HTMLTEXT;
}
?>
